package com.example.touchrecorder;

import java.util.ArrayList;
import java.util.List;

public class StateManager {
    public static final int STATE_IDLE = 0;
    public static final int STATE_RECORDING = 1;
    public static final int STATE_PLAYING = 2;

    private static StateManager instance;
    private int currentState = STATE_IDLE;
    private List<TouchEvent> recordedEvents = new ArrayList<>();
    private boolean isLoopPlayback = false;
    private OnStateChangeListener listener;

    private StateManager() {}

    public static StateManager getInstance() {
        if (instance == null) instance = new StateManager();
        return instance;
    }

    public int getCurrentState() { return currentState; }

    public void setCurrentState(int state) {
        currentState = state;
        if (listener != null) listener.onStateChanged(state);
    }

    public List<TouchEvent> getRecordedEvents() { return recordedEvents; }

    public void setRecordedEvents(List<TouchEvent> events) {
        recordedEvents = events;
    }

    public boolean isLoopPlayback() { return isLoopPlayback; }

    public void setLoopPlayback(boolean loop) {
        isLoopPlayback = loop;
    }

    public void setOnStateChangeListener(OnStateChangeListener l) {
        listener = l;
    }

    public interface OnStateChangeListener {
        void onStateChanged(int newState);
    }
}
