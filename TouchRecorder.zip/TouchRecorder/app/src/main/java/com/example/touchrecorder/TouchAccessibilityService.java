package com.example.touchrecorder;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;

import java.util.List;

public class TouchAccessibilityService extends AccessibilityService {
    private static TouchAccessibilityService instance;
    private long lastEventTime = 0;
    private boolean isRecording = false;
    private boolean isPlaying = false;

    public static TouchAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    protected boolean onGesture(int gestureId) {
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isRecording) {
            long now = System.currentTimeMillis();
            long diff = lastEventTime == 0 ? 0 : now - lastEventTime;
            lastEventTime = now;

            StateManager.getInstance().getRecordedEvents().add(new TouchEvent(
                    event.getAction(),
                    event.getRawX(),
                    event.getRawY(),
                    diff
            ));
        }
        return super.onTouchEvent(event);
    }

    public void startRecording() {
        isRecording = true;
        StateManager.getInstance().getRecordedEvents().clear();
        lastEventTime = 0;
        StateManager.getInstance().setCurrentState(StateManager.STATE_RECORDING);
    }

    public void stopRecording() {
        isRecording = false;
        StateManager.getInstance().setCurrentState(StateManager.STATE_IDLE);
    }

    public void startPlayback() {
        if (isPlaying) return;
        List<TouchEvent> events = StateManager.getInstance().getRecordedEvents();
        if (events == null || events.isEmpty()) return;

        isPlaying = true;
        StateManager.getInstance().setCurrentState(StateManager.STATE_PLAYING);

        new Thread(() -> playGestureSequence(events)).start();
    }

    public void stopPlayback() {
        isPlaying = false;
        StateManager.getInstance().setCurrentState(StateManager.STATE_IDLE);
    }

    private void playGestureSequence(List<TouchEvent> events) {
        do {
            Path path = new Path();
            long totalTime = 0;

            for (TouchEvent event : events) {
                if (!isPlaying) break;

                try {
                    Thread.sleep(event.timeDiff);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                totalTime += event.timeDiff;

                if (event.action == MotionEvent.ACTION_DOWN) {
                    path.moveTo(event.x, event.y);
                } else if (event.action == MotionEvent.ACTION_MOVE) {
                    path.lineTo(event.x, event.y);
                } else if (event.action == MotionEvent.ACTION_UP) {
                    path.lineTo(event.x, event.y);
                    dispatchGesture(path, totalTime);
                    path.reset();
                    totalTime = 0;
                }
            }

            if (StateManager.getInstance().isLoopPlayback() && isPlaying) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } while (StateManager.getInstance().isLoopPlayback() && isPlaying);

        isPlaying = false;
        StateManager.getInstance().setCurrentState(StateManager.STATE_IDLE);
    }

    private void dispatchGesture(Path path, long duration) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, duration));
        dispatchGesture(builder.build(), null, null);
    }

    @Override
    public void onInterrupt() {}

    public boolean isPlaying() { return isPlaying; }
    public boolean isRecording() { return isRecording; }
}
