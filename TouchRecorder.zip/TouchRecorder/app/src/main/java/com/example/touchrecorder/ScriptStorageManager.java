package com.example.touchrecorder;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ScriptStorageManager {
    private static final String SP_NAME = "touch_scripts";
    private static final String KEY_SCRIPTS = "script_list";
    private static final String KEY_CURRENT_ID = "current_script_id";

    private static ScriptStorageManager instance;
    private SharedPreferences sp;
    private Gson gson;

    private ScriptStorageManager(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public static ScriptStorageManager getInstance(Context context) {
        if (instance == null) {
            instance = new ScriptStorageManager(context);
        }
        return instance;
    }

    public List<RecordScript> getAllScripts() {
        String json = sp.getString(KEY_SCRIPTS, "");
        if (json.isEmpty()) return new ArrayList<>();
        Type type = new TypeToken<List<RecordScript>>(){}.getType();
        List<RecordScript> list = gson.fromJson(json, type);
        return list != null ? list : new ArrayList<>();
    }

    public void saveScript(RecordScript script) {
        List<RecordScript> scripts = getAllScripts();
        scripts.add(script);
        applyScripts(scripts);
        setCurrentScriptId(script.getId());
    }

    public void deleteScript(String scriptId) {
        List<RecordScript> scripts = getAllScripts();
        for (int i = 0; i < scripts.size(); i++) {
            if (scripts.get(i).getId().equals(scriptId)) {
                scripts.remove(i);
                break;
            }
        }
        applyScripts(scripts);
        if (scriptId.equals(getCurrentScriptId())) {
            setCurrentScriptId("");
        }
    }

    private void applyScripts(List<RecordScript> scripts) {
        sp.edit().putString(KEY_SCRIPTS, gson.toJson(scripts)).apply();
    }

    public String getCurrentScriptId() {
        return sp.getString(KEY_CURRENT_ID, "");
    }

    public void setCurrentScriptId(String id) {
        sp.edit().putString(KEY_CURRENT_ID, id).apply();
    }

    public RecordScript getCurrentScript() {
        String currentId = getCurrentScriptId();
        if (currentId.isEmpty()) return null;
        for (RecordScript script : getAllScripts()) {
            if (script.getId().equals(currentId)) {
                return script;
            }
        }
        return null;
    }
}
