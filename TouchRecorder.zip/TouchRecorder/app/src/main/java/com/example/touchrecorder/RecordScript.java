package com.example.touchrecorder;

import java.util.List;
import java.util.UUID;

public class RecordScript {
    private String id;
    private String name;
    private List<TouchEvent> eventList;
    private long createTime;

    public RecordScript(String name, List<TouchEvent> eventList) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.eventList = eventList;
        this.createTime = System.currentTimeMillis();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<TouchEvent> getEventList() { return eventList; }
    public long getCreateTime() { return createTime; }
}
