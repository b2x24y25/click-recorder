package com.example.touchrecorder;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView tvStatus;
    private Button btnRecord;
    private Button btnPlay;
    private Button btnFloat;
    private SwitchCompat switchLoop;
    private Button btnSaveScript;
    private Button btnChooseScript;
    private Button btnDeleteScript;

    private FloatWindowManager floatManager;
    private ScriptStorageManager storageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tv_status);
        btnRecord = findViewById(R.id.btn_record);
        btnPlay = findViewById(R.id.btn_play);
        btnFloat = findViewById(R.id.btn_float);
        switchLoop = findViewById(R.id.switch_loop);
        btnSaveScript = findViewById(R.id.btn_save_script);
        btnChooseScript = findViewById(R.id.btn_choose_script);
        btnDeleteScript = findViewById(R.id.btn_delete_script);

        floatManager = new FloatWindowManager(this);
        storageManager = ScriptStorageManager.getInstance(this);

        switchLoop.setChecked(StateManager.getInstance().isLoopPlayback());

        StateManager.getInstance().setOnStateChangeListener(newState -> {
            runOnUiThread(() -> updateMainUI(newState));
            floatManager.updateUI(newState);
        });

        btnRecord.setOnClickListener(v -> handleRecordClick());
        btnPlay.setOnClickListener(v -> handlePlayClick());
        btnFloat.setOnClickListener(v -> checkAndShowFloat());

        switchLoop.setOnCheckedChangeListener((buttonView, isChecked) -> {
            StateManager.getInstance().setLoopPlayback(isChecked);
            if (StateManager.getInstance().getCurrentState() == StateManager.STATE_IDLE) {
                updateMainUI(StateManager.STATE_IDLE);
                floatManager.updateUI(StateManager.STATE_IDLE);
            }
        });

        btnSaveScript.setOnClickListener(v -> showSaveDialog());
        btnChooseScript.setOnClickListener(v -> showChooseDialog());
        btnDeleteScript.setOnClickListener(v -> deleteCurrentScript());

        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "请先开启无障碍权限", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        loadCurrentScript();
    }

    private void loadCurrentScript() {
        RecordScript current = storageManager.getCurrentScript();
        if (current != null) {
            StateManager.getInstance().setRecordedEvents(current.getEventList());
            Toast.makeText(this, "已加载脚本：" + current.getName(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showSaveDialog() {
        List<TouchEvent> events = StateManager.getInstance().getRecordedEvents();
        if (events == null || events.isEmpty()) {
            Toast.makeText(this, "请先录制操作再保存", Toast.LENGTH_SHORT).show();
            return;
        }

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("请输入脚本名称");
        new AlertDialog.Builder(this)
                .setTitle("保存脚本")
                .setView(input)
                .setPositiveButton("保存", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(MainActivity.this, "名称不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    RecordScript script = new RecordScript(name, events);
                    storageManager.saveScript(script);
                    Toast.makeText(MainActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showChooseDialog() {
        List<RecordScript> scripts = storageManager.getAllScripts();
        if (scripts.isEmpty()) {
            Toast.makeText(this, "暂无保存的脚本", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] names = new String[scripts.size()];
        for (int i = 0; i < scripts.size(); i++) {
            names[i] = scripts.get(i).getName();
        }

        new AlertDialog.Builder(this)
                .setTitle("选择脚本")
                .setItems(names, (dialog, which) -> {
                    RecordScript selected = scripts.get(which);
                    StateManager.getInstance().setRecordedEvents(selected.getEventList());
                    storageManager.setCurrentScriptId(selected.getId());
                    Toast.makeText(MainActivity.this, "已加载：" + selected.getName(), Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void deleteCurrentScript() {
        String currentId = storageManager.getCurrentScriptId();
        if (currentId.isEmpty()) {
            Toast.makeText(this, "当前未选中脚本", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("确认删除")
                .setMessage("确定要删除当前脚本吗？")
                .setPositiveButton("删除", (dialog, which) -> {
                    storageManager.deleteScript(currentId);
                    StateManager.getInstance().setRecordedEvents(null);
                    Toast.makeText(MainActivity.this, "已删除", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void handleRecordClick() {
        TouchAccessibilityService service = TouchAccessibilityService.getInstance();
        if (service == null) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        if (StateManager.getInstance().getCurrentState() == StateManager.STATE_RECORDING) {
            service.stopRecording();
            Toast.makeText(this, "录制结束，共记录" +
                    StateManager.getInstance().getRecordedEvents().size() + "个事件", Toast.LENGTH_SHORT).show();
        } else {
            service.startRecording();
        }
    }

    private void handlePlayClick() {
        TouchAccessibilityService service = TouchAccessibilityService.getInstance();
        if (service == null) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        List<TouchEvent> events = StateManager.getInstance().getRecordedEvents();
        if (events == null || events.isEmpty()) {
            Toast.makeText(this, "请先录制或选择脚本", Toast.LENGTH_SHORT).show();
            return;
        }

        if (StateManager.getInstance().getCurrentState() == StateManager.STATE_PLAYING) {
            service.stopPlayback();
        } else {
            service.startPlayback();
        }
    }

    private void updateMainUI(int state) {
        boolean isLoop = StateManager.getInstance().isLoopPlayback();
        switch (state) {
            case StateManager.STATE_IDLE:
                tvStatus.setText(isLoop ? "当前状态：空闲(循环模式)" : "当前状态：空闲");
                btnRecord.setText("开始录制");
                btnPlay.setText("模拟执行");
                btnRecord.setEnabled(true);
                btnPlay.setEnabled(true);
                break;
            case StateManager.STATE_RECORDING:
                tvStatus.setText("当前状态：录制中...");
                btnRecord.setText("结束录制");
                btnPlay.setEnabled(false);
                break;
            case StateManager.STATE_PLAYING:
                tvStatus.setText(isLoop ? "当前状态：正在循环操作..." : "当前状态：正在操作...");
                btnPlay.setText("结束模拟");
                btnRecord.setEnabled(false);
                break;
        }
    }

    private void checkAndShowFloat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            }
        }
        floatManager.showFloatWindow();
        Toast.makeText(this, "悬浮窗已显示", Toast.LENGTH_SHORT).show();
        moveTaskToBack(true);
    }

    private boolean isAccessibilityEnabled() {
        int enabled = 0;
        try {
            enabled = Settings.Secure.getInt(getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        if (enabled == 1) {
            String services = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return services != null && services.contains(getPackageName());
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        floatManager.hideFloatWindow();
    }
}
