package com.example.touchrecorder;

public class TouchEvent {
    public int action;
    public float x;
    public float y;
    public long timeDiff;

    public TouchEvent(int action, float x, float y, long timeDiff) {
        this.action = action;
        this.x = x;
        this.y = y;
        this.timeDiff = timeDiff;
    }
}
